import pandas as pd
import pickle
import sys

MODEL_FILE = "ml/random_forest_model.pkl"

try:
   with open(MODEL_FILE, "rb") as file:
       package = pickle.load(file)
except FileNotFoundError:
    print("Random Forest model not found.")
    print("Train the model after collecting enough records.")
    sys.exit(1)

preprocessor = package["preprocessor"]
model = package["model"]
label_encoder = package["label_encoder"]
features = package["features"]

if len(sys.argv) < 2:
   print("usage:")
   print("python ml/predict.py <input_csv>")
   sys.exit(1)

input_file = sys.argv[1]

df = pd.read_csv(input_file)

missing = [column for column in features if column not in df.columns]

if missing:
    print("Missing features:")
    print(missing)
    sys.exit(1)

x = df[features].fillna("")

X_encoded = preprocessor.transform(x)

predictions = model.predict(X_encoded)

df["predicted_attack_type"] = label_encoder.inverse_transform(predictions)

print("\nPrediction results:")
print(df[["predicted_attack_type"]].to_string(index=False))
print("\nPrediction completed.")
